document.addEventListener("DOMContentLoaded", () => {
  const convertBtn = document.getElementById("convertBtn");
  const resetBtn = document.getElementById("resetBtn");
  const resultBox = document.getElementById("result");
  const tempInput = document.getElementById("tempInput");
  const historyList = document.getElementById("historyList");
  const clearBtn = document.getElementById("clearHistoryBtn");
  const formPanel = document.querySelector(".form-panel");

  function highlightConverterPanel() {
  formPanel.classList.add("highlighted");
  setTimeout(() => {
    formPanel.classList.remove("highlighted");
  }, 4000);
}

  const converterLink = document.getElementById("converterLink");
const toggleSidebar = document.getElementById("toggleSidebar");

converterLink.addEventListener("click", () => {
  toggleSidebar.checked = true; // ✅ Show converter panel
});


  // Clear History button
  clearBtn.addEventListener("click", () => {
    historyList.innerHTML = "";
  });

  // Convert temperature
  convertBtn.addEventListener("click", () => {
    const inputValue = tempInput.value.trim();
    const fromUnit = document.querySelector("input[name='fromUnit']:checked").value;
    const toUnit = document.querySelector("input[name='toUnit']:checked").value;

    highlightConverterPanel();

    // Validate input
    if (inputValue === "" || isNaN(inputValue)) {
      showAlert("Invalid input. Please enter a valid number.");
      return;
    }

    const temperature = parseFloat(inputValue);
    let tempInCelsius;

    switch (fromUnit) {
      case "celsius":
        tempInCelsius = temperature;
        break;
      case "fahrenheit":
        tempInCelsius = (temperature - 32) * (5 / 9);
        break;
      case "kelvin":
        tempInCelsius = temperature - 273.15;
        break;
    }

    let result;
    switch (toUnit) {
      case "celsius":
        result = tempInCelsius;
        break;
      case "fahrenheit":
        result = tempInCelsius * (9 / 5) + 32;
        break;
      case "kelvin":
        result = tempInCelsius + 273.15;
        break;
    }

    const unitSymbol = getUnitSymbol(toUnit);
    const output = `${temperature}° ${capitalize(fromUnit)} = ${result.toFixed(2)}° ${unitSymbol}`;

    // Show result box
resultBox.textContent = output;
    resultBox.style.display = "block";
    resultBox.style.opacity = "1";
    resultBox.style.animation = "fadeIn 0.4s ease forwards";

    // Timestamp
    const now = new Date();
    const timestamp = now.toLocaleString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "numeric",
      hour12: true,
    });

    // Log to history
    const historyItem = document.createElement("li");
    historyItem.innerHTML = `<strong>${timestamp}</strong><br>${output}`;
    historyList.prepend(historyItem);
  });

  // Reset button
  resetBtn.addEventListener("click", () => {
    tempInput.value = "";
    resultBox.textContent = "";
    resultBox.style.display = "none";
    resultBox.style.animation = "";
  });

  function capitalize(word) {
    return word.charAt(0).toUpperCase() + word.slice(1);
  }

  function getUnitSymbol(unit) {
    switch (unit) {
      case "celsius": return "C";
      case "fahrenheit": return "F";
      case "kelvin": return "K";
    }
  }

  function showAlert(message) {
    const alertBox = document.createElement("div");
    alertBox.style.position = "fixed";
    alertBox.style.top = "50%";
    alertBox.style.left = "50%";
    alertBox.style.transform = "translate(-50%, -50%)";
    alertBox.style.background = "#fff";
    alertBox.style.border = "2px solid #f44336";
    alertBox.style.padding = "20px";
    alertBox.style.zIndex = "9999";
    alertBox.style.boxShadow = "0 0 10px rgba(0,0,0,0.2)";
    alertBox.style.borderRadius = "8px";
    alertBox.style.textAlign = "center";
    alertBox.innerHTML = `
      <p style="margin-bottom: 15px; font-weight: bold; color: #f44336;">${message}</p>
      <button style="padding: 8px 16px; background: #f44336; color: white; border: none; border-radius: 5px; cursor: pointer;">Close</button>
    `;
    alertBox.querySelector("button").addEventListener("click", () => {
      document.body.removeChild(alertBox);
    });
    document.body.appendChild(alertBox);
  }
});
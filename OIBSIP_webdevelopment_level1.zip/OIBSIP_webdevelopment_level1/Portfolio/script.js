
// Roles cycling
const roles = ["Web Developer", "Front-End Developer", "Design-Driven Developer"];
let rIndex = 0;
const roleEl = document.getElementById("roleText");
function cycleRoles() {
    rIndex = (rIndex + 1) % roles.length;
    roleEl.style.opacity = 0;
    setTimeout(() => {
        roleEl.textContent = roles[rIndex];
        roleEl.style.opacity = 1;
    }, 220);
}
setInterval(cycleRoles, 2200);

// Filters
const filterButtons = document.querySelectorAll(".filter-btn");
const cards = document.querySelectorAll(".card");

filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        // set active state
        filterButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const filter = btn.dataset.filter;
        cards.forEach(card => {
            const cat = card.dataset.category;
            const show = filter === "all" || cat === filter;
            card.style.display = show ? "flex" : "none";
        });
    });
});

const toggleBtn = document.getElementById("theme-toggle");

// Start in dark mode
document.body.classList.remove("light");
toggleBtn.textContent = "🌞 Light Mode";

toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("light");

  if (document.body.classList.contains("light")) {
    toggleBtn.textContent = "🌙 Dark Mode";
  } else {
    toggleBtn.textContent = "🌞 Light Mode";
  }
});
const shoeImages = ["images/men2.png", "images/shoe2.webp", "images/formal_men.png", "images/kid.png", "images/kid2.png", "images/women1.png", "images/women_dailywear.png"]; // Replace with your actual image filenames
let currentIndex = 0;
const shoeImg = document.getElementById("shoeImage");

setInterval(() => {
  currentIndex = (currentIndex + 1) % shoeImages.length;
  shoeImg.style.opacity = 0;
  setTimeout(() => {
    shoeImg.src = shoeImages[currentIndex];
    shoeImg.style.opacity = 1;
  }, 300);
}, 4000);

function showMore() {
  const hidden = document.querySelector('.hidden-paragraphs');
  hidden.classList.add('show');
  document.querySelector('.learn-more-btn').style.display = 'none';
}

const track = document.querySelector('.slides-track');
const slides = document.querySelectorAll('.slide');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');

let slideIndex = 0;

function updateSlidePosition() {
  const offset = -slideIndex * 100; // move by full slide width
  track.style.transform = `translateX(${offset}%)`;
}

prevBtn.addEventListener('click', () => {
  slideIndex = (slideIndex - 1 + slides.length) % slides.length;
  updateSlidePosition();
});

nextBtn.addEventListener('click', () => {
  slideIndex = (slideIndex + 1) % slides.length;
  updateSlidePosition();
});

updateSlidePosition();

const contactForm = document.querySelector('.contact-form');
const feedbackMsg = document.getElementById('formFeedback');

contactForm.addEventListener('submit', function (e) {
  e.preventDefault(); // prevent actual submission

  // Optionally: validate fields here

  // Show feedback message
  feedbackMsg.style.display = 'block';

  // Clear form fields
  contactForm.reset();

  // Hide message after a few seconds
  setTimeout(() => {
    feedbackMsg.style.display = 'none';
  }, 5000);
});